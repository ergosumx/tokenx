# Tokenizer Benchmark Comparison

Generated on 2025-10-18 01:48:53 UTC

This report compares the HuggingFace and Microsoft.ML tokenizers across multiple workloads. Metrics reflect the latest BenchmarkDotNet run using the extended configuration.

## BertTokenizerBenchmarks — DecodeBatch — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 2.544 | 0.369 |    2.3% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 112.898 | 12.894 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeBatch — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 1.252 | 0.130 |    2.0% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 62.061 | 7.929 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeBatch — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 2.787 | 0.418 |    1.8% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 154.234 | 37.818 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeBatch — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.719 | 0.291 |    2.2% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 32.440 | 2.537 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeBatch — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 1.206 | 0.240 |   23.8% | █████░░░░░░░░░░░░░░░ |
| HuggingFace | 5.059 | 0.616 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeBatch — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.565 | 0.111 |   22.1% | ████░░░░░░░░░░░░░░░░ |
| HuggingFace | 2.551 | 0.194 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.188 | 0.025 |    6.0% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 3.157 | 0.140 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.191 | 0.062 |    8.3% | ██░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 2.283 | 0.742 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.287 | 0.034 |    3.7% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 7.827 | 1.337 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.171 | 0.063 |   15.0% | ███░░░░░░░░░░░░░░░░░ |
| HuggingFace | 1.139 | 0.320 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.099 | 0.047 |   20.7% | ████░░░░░░░░░░░░░░░░ |
| HuggingFace | 0.476 | 0.077 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — DecodeSingle — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.083 | 0.039 |   24.9% | █████░░░░░░░░░░░░░░░ |
| HuggingFace | 0.332 | 0.077 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 10.834 | 1.946 |    4.6% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 237.216 | 23.562 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 4.996 | 0.526 |    3.6% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 137.552 | 27.487 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 9.286 | 1.064 |    3.4% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 270.072 | 26.796 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 2.866 | 1.237 |    6.3% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 45.452 | 8.117 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 2.430 | 1.103 |   18.2% | ████░░░░░░░░░░░░░░░░ |
| HuggingFace | 13.378 | 2.819 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeBatch — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 1.623 | 0.303 |   17.3% | ███░░░░░░░░░░░░░░░░░ |
| HuggingFace | 9.378 | 2.679 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.327 | 0.036 |    4.7% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 6.928 | 0.767 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.323 | 0.104 |    6.9% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 4.672 | 1.048 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.724 | 0.131 |    4.3% | █░░░░░░░░░░░░░░░░░░░ |
| HuggingFace | 16.867 | 2.700 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.269 | 0.178 |   18.2% | ████░░░░░░░░░░░░░░░░ |
| HuggingFace | 1.477 | 0.222 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.276 | 0.085 |   32.5% | ███████░░░░░░░░░░░░░ |
| HuggingFace | 0.849 | 0.246 |  100.0% | ████████████████████ |

## BertTokenizerBenchmarks — EncodeSingle — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.242 | 0.091 |   25.8% | █████░░░░░░░░░░░░░░░ |
| HuggingFace | 0.935 | 0.293 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 9.226 | 0.422 |   55.8% | ███████████░░░░░░░░░ |
| HuggingFace | 16.542 | 1.209 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 6.550 | 0.995 |   50.1% | ██████████░░░░░░░░░░ |
| HuggingFace | 13.063 | 4.113 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 9.882 | 1.119 |   61.5% | ████████████░░░░░░░░ |
| HuggingFace | 16.076 | 0.799 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 1.189 | 0.047 |   51.0% | ██████████░░░░░░░░░░ |
| HuggingFace | 2.329 | 0.243 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.926 | 0.159 |   40.0% | ████████░░░░░░░░░░░░ |
| Microsoft | 2.318 | 1.528 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeBatch — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.444 | 0.044 |   37.4% | ███████░░░░░░░░░░░░░ |
| Microsoft | 1.187 | 0.346 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.663 | 0.159 |   73.5% | ███████████████░░░░░ |
| HuggingFace | 0.902 | 0.181 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.360 | 0.033 |   63.6% | █████████████░░░░░░░ |
| HuggingFace | 0.565 | 0.133 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.850 | 0.103 |   68.9% | ██████████████░░░░░░ |
| HuggingFace | 1.233 | 0.120 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| Microsoft | 0.145 | 0.038 |   96.5% | ███████████████████░ |
| HuggingFace | 0.150 | 0.007 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.089 | 0.005 |   89.5% | ██████████████████░░ |
| Microsoft | 0.100 | 0.045 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — DecodeSingle — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.096 | 0.011 |   87.9% | ██████████████████░░ |
| Microsoft | 0.110 | 0.021 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 235.066 | 30.282 |   17.4% | ███░░░░░░░░░░░░░░░░░ |
| Microsoft | 1351.578 | 109.457 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 105.762 | 13.606 |   25.6% | █████░░░░░░░░░░░░░░░ |
| Microsoft | 413.665 | 43.725 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 264.245 | 34.719 |   10.7% | ██░░░░░░░░░░░░░░░░░░ |
| Microsoft | 2477.800 | 391.225 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 18.919 | 1.314 |   49.3% | ██████████░░░░░░░░░░ |
| Microsoft | 38.381 | 2.502 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 5.988 | 0.578 |   81.9% | ████████████████░░░░ |
| Microsoft | 7.307 | 0.461 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeBatch — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 3.403 | 0.408 |   60.6% | ████████████░░░░░░░░ |
| Microsoft | 5.613 | 2.376 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Extra(...)kens) [25]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 7.979 | 2.334 |   16.3% | ███░░░░░░░░░░░░░░░░░ |
| Microsoft | 49.067 | 11.355 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Long (≈512 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 2.819 | 0.514 |   30.4% | ██████░░░░░░░░░░░░░░ |
| Microsoft | 9.272 | 0.628 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Massi(...)kens) [22]

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 15.356 | 4.163 |   10.5% | ██░░░░░░░░░░░░░░░░░░ |
| Microsoft | 146.744 | 10.768 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Medium (≈128 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.737 | 0.039 |   51.8% | ██████████░░░░░░░░░░ |
| Microsoft | 1.424 | 0.168 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Short (≈32 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.374 | 0.047 |   36.1% | ███████░░░░░░░░░░░░░ |
| Microsoft | 1.035 | 0.345 |  100.0% | ████████████████████ |

## Gpt2TokenizerBenchmarks — EncodeSingle — Tiny (≈16 tokens)

| Implementation | Mean (ms) | StdDev (ms) | Relative | Graph |
| -------------- | --------: | ----------: | -------: | :---- |
| HuggingFace | 0.400 | 0.043 |   47.8% | ██████████░░░░░░░░░░ |
| Microsoft | 0.836 | 0.204 |  100.0% | ████████████████████ |

